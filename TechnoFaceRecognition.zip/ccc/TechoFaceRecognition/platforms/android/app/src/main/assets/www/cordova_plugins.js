cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "cordova-plugin-techofacerecognition.TecholutionFaceRecognitionPlugin",
    "file": "plugins/cordova-plugin-techofacerecognition/www/TecholutionFaceRecognitionPlugin.js",
    "pluginId": "cordova-plugin-techofacerecognition",
    "clobbers": [
      "cordova.plugins"
    ]
  },
  {
    "id": "cordovapluginamilateyou.amilateyou",
    "file": "plugins/cordovapluginamilateyou/www/amilateyou.js",
    "pluginId": "cordovapluginamilateyou",
    "clobbers": [
      "cordova.plugins.amilateyou"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-plugin-techofacerecognition": "0.0.1",
  "cordova-plugin-whitelist": "1.3.3",
  "cordovapluginamilateyou": "0.0.3"
};
// BOTTOM OF METADATA
});